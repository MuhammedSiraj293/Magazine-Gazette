'use client'
import React from 'react';

export const DataContext = React.createContext(null);