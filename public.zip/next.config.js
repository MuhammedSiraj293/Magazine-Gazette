module.exports = {
    images: {
      domains: ['free-domain.in'],
    },
  }